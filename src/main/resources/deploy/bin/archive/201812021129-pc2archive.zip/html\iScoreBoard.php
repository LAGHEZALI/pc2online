<html>
    <script src="JQuery/jquery-1.9.1.js"></script><script src="JQuery/jquery-ui.js"></script>
    <link href="table_sorter/css/theme.default.css" rel="stylesheet">
    <script type="text/javascript" src="table_sorter/js/jquery.tablesorter.min.js"></script><script type="text/javascript" src="table_sorter/js/jquery.tablesorter.widgets.min.js"></script><script type="text/javascript">
$(function() {
	$( "#tabs" ).tabs();
	$('table').tablesorter({
			sortList: [[0,0]],
			widgets        : ['zebra', 'columns'],
			usNumberFormat : true,
			sortRestart    : true
	});
});
</script>
    <body>
        <table style="empty-cells:show;" id="veiwStandingTable" class="tablesorter" border="1px">
            <thead>
                <tr>
                    <th>Rank</th><th>Team Name</th><th>Solved</th><th>Time</th><th>Problem A</th><th>Problem B</th><th>Problem C</th><th>Problem D</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td><td>team1</td><td>0</td><td>0</td><td style="text-align:center;border-color:white;">0/--</td><td style="text-align:center;border-color:white;">0/--</td><td style="text-align:center;border-color:white;">0/--</td><td style="text-align:center;border-color:white;">0/--</td>
                </tr>
                <tr>
                    <td>1</td><td>team2</td><td>0</td><td>0</td><td style="text-align:center;border-color:white;">0/--</td><td style="text-align:center;border-color:white;">0/--</td><td style="text-align:center;border-color:white;">0/--</td><td style="text-align:center;border-color:white;">0/--</td>
                </tr>
                <tr>
                    <td>1</td><td>team3</td><td>0</td><td>0</td><td style="text-align:center;border-color:white;">0/--</td><td style="text-align:center;border-color:white;">0/--</td><td style="text-align:center;border-color:white;">0/--</td><td style="text-align:center;border-color:white;">0/--</td>
                </tr>
            </tbody>
        </table>
    </body>
</html>
