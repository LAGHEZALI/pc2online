#include <stdio.h>
#include <stdlib.h>

int main()
{
    int c=0,n,i=0,x;
    float y=0;

    scanf("%d %d",&n,&x);

        for(i=1;i<=n;i++)
        {
            y=(float)x/i;
            if(y-((int)y)==0&&y&&y<=n)
            {
            c++;
            }
        }

    printf("%d",c);
    return 0;
}
