import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import Interfaces.Forum;

public class Main {

	public static void main(String[] args) {
		try {
			System.out.println("Creating server object");
			Forum forum = new ForumImpl();
			System.out.println("RMI Registry Referencing");
			Registry reg = LocateRegistry.createRegistry(1099);
			reg.rebind("Forum", forum);
//			Naming.rebind("rmi://192.168.137.204:1099/Forum", forum);
            System.out.println("Waiting Invokations");
		}catch(Exception e) {
			System.out.println("Exception");
			e.printStackTrace();
		}
	}
}
